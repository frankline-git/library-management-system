		<div class="span12">
				<div class="header">
				<div class="pull-left">
				<img class="stilogo" src="LMS/m library.jpg">
				</div>
				</div>

					<div class="alert alert-info"><Strong></strong>&nbsp;Welcome to M Library Management System
					
					
					
	
								
							<div class="pull-right">
								
								<?php
								
								
				
								?>
							</div>
					</div>
				
					
				</div>