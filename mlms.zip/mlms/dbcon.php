<?php
mysqli_select_db('mlms',mysqli_connect('localhost','root',''))or die(mysqli_error());
?>