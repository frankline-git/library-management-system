<?php 
include('dbcon.php');
if (isset($_POST['submit'])) {
    $book_title = $_POST['book_title'];
    $category_id = $_POST['category_id'];
    $author = $_POST['author'];
    $book_copies = $_POST['book_copies'];
    $book_pub = $_POST['book_pub'];
    $publisher_name = $_POST['publisher_name'];
    $isbn = $_POST['isbn'];
    $copyright_year = $_POST['copyright_year'];
    $status = $_POST['status'];

    // Initialize book_image variable
    $book_image = '';

    // Handle image upload
    if (isset($_FILES['book_image']) && $_FILES['book_image']['error'] == UPLOAD_ERR_OK) {
        $file_name = $_FILES['book_image']['name'];
        $file_tmp = $_FILES['book_image']['tmp_name'];
        $target_dir = "Uploads/";
        $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');

        // Sanitize and generate a unique file name
        $unique_name = time() . '_' . basename($file_name);
        $target_file = $target_dir . $unique_name;

        // Check if file is an allowed image type
        if (in_array($file_extension, $allowed_extensions)) {
            // Move the uploaded file to the target directory
            if (move_uploaded_file($file_tmp, $target_file)) {
                $book_image = $unique_name; // Store the unique file name
            } else {
                // Log error or handle failure (e.g., permission issues)
                $book_image = 'default.jpg'; // Fallback to default if upload fails
            }
        } else {
            $book_image = 'default.jpg'; // Fallback if file type is not allowed
        }
    } else {
        $book_image = 'default.jpg'; // Default image if no file is uploaded
    }

    // Insert into database including book_image
    $query = mysqli_query($conn, "INSERT INTO book (book_title, category_id, author, book_copies, book_pub, publisher_name, isbn, copyright_year, date_added, status, book_image)
        VALUES ('$book_title', '$category_id', '$author', '$book_copies', '$book_pub', '$publisher_name', '$isbn', '$copyright_year', NOW(), '$status', '$book_image')") 
        or die(mysqli_error($conn));

    header('location:books.php');
}
?>