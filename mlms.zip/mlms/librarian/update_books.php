<?php
include('dbcon.php');

if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $book_title = $_POST['book_title'];
    $category_id = $_POST['category_id'];
    $author = $_POST['author'];
    $book_copies = $_POST['book_copies'];
    $book_pub = $_POST['book_pub'];
    $publisher_name = $_POST['publisher_name'];
    $isbn = $_POST['isbn'];
    $copyright_year = $_POST['copyright_year'];
    $status = $_POST['status'];

    // Fetch current book data to get the old image
    $query = mysqli_query($conn, "SELECT book_image FROM book WHERE book_id = '$id'");
    $row = mysqli_fetch_array($query);
    $old_image = $row['book_image'];

    // Handle image upload
    $book_image = $old_image; // Retain old image by default
    if (isset($_FILES['book_image']) && $_FILES['book_image']['error'] == 0) {
        $target_dir = "uploads/";
        
        // Create uploads directory if it doesn't exist
        if (!file_exists($target_dir)) {
            if (!mkdir($target_dir, 0777, true)) {
                echo "Failed to create directory: $target_dir";
                exit;
            }
        }

        // Ensure the directory is writable
        if (!is_writable($target_dir)) {
            echo "Directory $target_dir is not writable. Please set the correct permissions (e.g., chmod 777 uploads/).";
            exit;
        }

        $image_name = time() . "_" . basename($_FILES['book_image']['name']);
        $target_file = $target_dir . $image_name;

        // Validate file type (only allow images)
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = array("jpg", "jpeg", "png", "gif");
        if (!in_array($imageFileType, $allowed_types)) {
            echo "Only JPG, JPEG, PNG, and GIF files are allowed.";
            exit;
        }

        // Attempt to move the uploaded file
        if (move_uploaded_file($_FILES['book_image']['tmp_name'], $target_file)) {
            $book_image = $image_name; // Update with new image name
            // Optionally delete the old image
            if (!empty($old_image) && file_exists($target_dir . $old_image)) {
                unlink($target_dir . $old_image);
            }
        } else {
            // Log the error for debugging
            $error = error_get_last();
            echo "Error uploading image. Details: " . $error['message'];
            exit;
        }
    } elseif ($_FILES['book_image']['error'] != UPLOAD_ERR_NO_FILE) {
        // Handle other upload errors
        echo "File upload error: " . $_FILES['book_image']['error'];
        exit;
    }

    // Update database
    mysqli_query($conn, "UPDATE book SET 
              book_title = '$book_title', 
              category_id = '$category_id', 
              author = '$author', 
              book_copies = '$book_copies', 
              book_pub = '$book_pub', 
              publisher_name = '$publisher_name', 
              isbn = '$isbn', 
              copyright_year = '$copyright_year', 
              status = '$status', 
              book_image = '$book_image' 
              WHERE book_id = '$id'") or die(mysqli_error($conn));

    header('location:books.php');
}
?>