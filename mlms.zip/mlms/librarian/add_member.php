<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_member.php'); ?>
<div class="container">
    <div class="margin-top">
        <div class="row">    
            <div class="span12">    
                <div class="alert alert-info">Add Member</div>
                <p><a href="member.php" class="btn btn-info"><i class="icon-arrow-left icon-large"></i>&nbsp;Back</a></p>
                <div class="addstudent">
                    <div class="details">Please Enter Details Below</div>        
                    <form class="form-horizontal" method="POST" action="member_save.php" enctype="multipart/form-data">
                        <!-- Admission No field -->
                        <div class="control-group">
                            <label class="control-label" for="admissionNo">Admission No:</label>
                            <div class="controls">
                                <input type="text" id="admissionNo" name="admission_no" placeholder="Admission No">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="inputEmail">Firstname:</label>
                            <div class="controls">
                                <input type="text" id="inputEmail" name="firstname" placeholder="Firstname" required>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="inputPassword">Lastname:</label>
                            <div class="controls">
                                <input type="text" id="inputPassword" name="lastname" placeholder="Lastname" required>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="inputPassword">Gender:</label>
                            <div class="controls">
                                <select name="gender" required>
                                    <option value="" disabled selected>Select Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="inputPassword">Address:</label>
                            <div class="controls">
                                <input type="text" id="inputPassword" name="address" placeholder="Address" required>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="inputPassword">Cellphone Number:</label>
                            <div class="controls">
                                <input type="tel" pattern="[0-9]{0,15}" class="search" name="contact" placeholder="Phone Number" autocomplete="off" maxlength="15">
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="inputPassword">Type:</label>
                            <div class="controls">
                                <select name="type" id="type" required onchange="toggleAdmissionNo()">
                                    <option value="" disabled selected>Select Type</option>
                                    <option value="Student">Student</option>
                                    <option value="Teacher">Lecturer/Teacher</option>
                                    <option value="Non Teaching Staff">Non Teaching Staff</option>
                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="inputPassword">Year Level:</label>
                            <div class="controls">
                                <select name="year_level" required>
                                    <option value="" disabled selected>Select Year Level</option>
                                    <option value="First Year">First Year</option>
                                    <option value="Second Year">Second Year</option>
                                    <option value="Third Year">Third Year</option>
                                    <option value="Fourth Year">Fourth Year</option>
                                    <option value="Faculty">Faculty</option>
                                    <option value="Teacher">Lecturer/Teacher</option>
                                    <option value="Researcher">Researcher</option>
                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <label class="control-label" for="inputPassword">Status:</label>
                            <div class="controls">
                                <select name="status" required>
                                    <option value="" disabled selected>Select Status</option>
                                    <option value="Active">Active</option>
                                    <option value="Banned">Banned</option>
                                </select>
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="controls">
                                <button name="submit" type="submit" class="btn btn-success"><i class="icon-save icon-large"></i>&nbsp;Save</button>
                            </div>
                        </div>
                    </form>                    
                </div>        
            </div>        
        </div>
    </div>
</div>

<script>
function toggleAdmissionNo() {
    var typeSelect = document.getElementById('type');
    var admissionNoInput = document.getElementById('admissionNo');
    
    if (typeSelect.value === 'Student') {
        admissionNoInput.setAttribute('required', 'required');
    } else {
        admissionNoInput.removeAttribute('required');
    }
}
</script>

<?php include('footer.php') ?>