<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_books.php'); ?>
<?php $get_id = $_GET['id']; ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">	
			<div class="span12">	
		<?php 
		$query = mysqli_query($conn, "SELECT * FROM book LEFT JOIN category ON category.category_id = book.category_id WHERE book_id='$get_id'") or die(mysqli_error());
		$row = mysqli_fetch_array($query);
		$category_id = $row['category_id'];
		?>
             <div class="alert alert-info"><i class="icon-pencil"></i> Edit Books</div>
			<p><a class="btn btn-info" href="books.php"><i class="icon-arrow-left icon-large"></i> Back</a></p>
	<div class="addstudent">
	<div class="details">Please Enter Details Below</div>	
	<form class="form-horizontal" method="POST" action="update_books.php" enctype="multipart/form-data">
			
		<div class="control-group">
			<label class="control-label" for="inputEmail">Book Title:</label>
			<div class="controls">
			<input type="text" class="span4" id="inputEmail" name="book_title" value="<?php echo $row['book_title']; ?>" placeholder="Book Title" required>
			<input type="hidden" id="inputEmail" name="id" value="<?php echo $get_id; ?>" placeholder="book_title" required>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputPassword">Category:</label>
			<div class="controls">
			<select name="category_id">
				<option value="<?php echo $category_id; ?>"><?php echo $row['classname']; ?></option>
				<?php 
				$query1 = mysqli_query($conn, "SELECT * FROM category WHERE category_id != '$category_id'") or die(mysqli_error());
				while ($row1 = mysqli_fetch_array($query1)) {
				?>
				<option value="<?php echo $row1['category_id']; ?>"><?php echo $row1['classname']; ?></option>
				<?php } ?>
			</select>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputPassword">Author:</label>
			<div class="controls">
			<input type="text" class="span4" id="inputPassword" name="author" value="<?php echo $row['author']; ?>" placeholder="Author" required>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="bookImage">Book Image:</label>
			<div class="controls">
				<!-- Display current image if it exists -->
				<?php if (!empty($row['book_image']) && file_exists('Uploads/' . $row['book_image'])) { ?>
					<img id="currentImage" src="Uploads/<?php echo htmlspecialchars($row['book_image']); ?>" alt="Current Book Image" style="max-width: 200px; max-height: 200px;">
				<?php } else { ?>
					<img id="currentImage" src="Uploads/default.jpg" alt="Default Image" style="max-width: 200px; max-height: 200px;">
				<?php } ?>
				<!-- Input to upload new image -->
				<input type="file" id="book_image" name="book_image" accept="image/*" onchange="previewImage(this)" style="margin-top: 10px;">
				<div style="margin-top: 10px;">
					<img id="imagePreview" src="#" alt="New Book Image Preview" style="max-width: 200px; max-height: 200px; display: none;">
				</div>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputPassword">Book Copies:</label>
			<div class="controls">
			<input class="span1" type="text" id="inputPassword" name="book_copies" value="<?php echo $row['book_copies']; ?>" placeholder="Book Copies" required>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputPassword">Book Pub:</label>
			<div class="controls">
			<input type="text" class="span4" id="inputPassword" name="book_pub" value="<?php echo $row['book_pub']; ?>" placeholder="Book Publication" required>
			</div>
		</div>	
		<div class="control-group">
			<label class="control-label" for="inputPassword">Publisher Name:</label>
			<div class="controls">
			<input type="text" class="span4" id="inputPassword" name="publisher_name" value="<?php echo $row['publisher_name']; ?>" placeholder="Publisher Name" required>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputPassword">ISBN:</label>
			<div class="controls">
			<input type="text" class="span4" id="inputPassword" name="isbn" value="<?php echo $row['isbn']; ?>" placeholder="ISBN" required>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputPassword">Copyright Year:</label>
			<div class="controls">
			<input type="text" id="inputPassword" name="copyright_year" value="<?php echo $row['copyright_year']; ?>" placeholder="Copyright Year" required>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputPassword">Status:</label>
			<div class="controls">
			<select name="status">
				<option><?php echo $row['status']; ?></option>
				<option>New</option>
				<option>Old</option>
				<option>Lost</option>
				<option>Damage</option>
				<option>Subject for Replacement</option>
			</select>
			</div>
		</div>
		<div class="control-group">
			<div class="controls">
			<button name="submit" type="submit" class="btn btn-success"><i class="icon-save icon-large"></i> Update</button>
			</div>
		</div>
    </form>				
	</div>		
	</div>		
	</div>
</div>

<script>
function previewImage(input) {
    var preview = document.getElementById('imagePreview');
    var currentImage = document.getElementById('currentImage');
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function(e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
            if (currentImage) {
                currentImage.style.display = 'none';
            }
        };
        reader.readAsDataURL(input.files[0]);
    } else {
        preview.src = '#';
        preview.style.display = 'none';
        if (currentImage) {
            currentImage.style.display = 'block';
        }
    }
}
</script>

<?php include('footer.php') ?>