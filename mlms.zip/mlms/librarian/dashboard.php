<DOCUMENT filename="dashboard.php">
<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_dashboard.php'); ?>
    <div class="container">
        <div class="margin-top">
            <div class="row">    
                <div class="span12">           
                    <?php include('slider.php'); ?>

                    <?php
                    // Database connection (updated to mlms)
                    $conn = new mysqli("localhost", "root", "", "mlms");

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Fetch totals
                    $total_borrows = $conn->query("SELECT COUNT(*) as count FROM borrow")->fetch_assoc()['count'];
                    $total_members = $conn->query("SELECT COUNT(*) as count FROM member")->fetch_assoc()['count'];
                    $total_books = $conn->query("SELECT COUNT(*) as count FROM book")->fetch_assoc()['count'];
                    $total_users = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];

                    $conn->close();
                    ?>

                    <!-- Stats Display -->
                    <div class="stats-container">
                        <div class="stat-box" style="background-color: #e74c3c;">
                            <i class="fas fa-exchange-alt" style="color: white;"></i>
                            <h3 style="color: white;">Total Borrows</h3>
                            <p style="color: white; font-size: 24px; font-weight: bold;"><?php echo $total_borrows; ?></p>
                        </div>
                        <div class="stat-box" style="background-color: #3498db;">
                            <i class="fas fa-users" style="color: white;"></i>
                            <h3 style="color: white;">Total Members</h3>
                            <p style="color: white; font-size: 24px; font-weight: bold;"><?php echo $total_members; ?></p>
                        </div>
                        <div class="stat-box" style="background-color: #2ecc71;">
                            <i class="fas fa-book" style="color: white;"></i>
                            <h3 style="color: white;">Total Books</h3>
                            <p style="color: white; font-size: 24px; font-weight: bold;"><?php echo $total_books; ?></p>
                        </div>
                        <div class="stat-box" style="background-color: #f1c40f;">
                            <i class="fas fa-user" style="color: white;"></i>
                            <h3 style="color: white;">Total Users</h3>
                            <p style="color: white; font-size: 24px; font-weight: bold;"><?php echo $total_users; ?></p>
                        </div>
                    </div>

                    <style>
                    .stats-container {
                        display: flex;
                        justify-content: space-around;
                        margin-top: 20px;
                    }
                    .stat-box {
                        padding: 20px;
                        border-radius: 10px;
                        text-align: center;
                        width: 20%;
                        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                        transition: transform 0.2s;
                    }
                    .stat-box:hover {
                        transform: scale(1.05);
                    }
                    .stat-box i {
                        font-size: 30px;
                        margin-bottom: 10px;
                    }
                    </style>
                </div>        
            </div>
        </div>
    </div>
<?php include('footer.php') ?>
</DOCUMENT>