<?php
include('dbcon.php');

if (isset($_POST['submit'])) {
    // Sanitize and retrieve input
    $admission_no = trim($_POST['admission_no']);
    $firstname = trim($_POST['firstname']);
    $lastname = trim($_POST['lastname']);
    $gender = trim($_POST['gender']);
    $address = trim($_POST['address']);
    $contact = trim($_POST['contact']);
    $type = trim($_POST['type']);
    $year_level = trim($_POST['year_level']);
    $status = trim($_POST['status']);

    // Validate required fields
    if (empty($firstname) || empty($lastname) || empty($gender) || empty($address) || empty($contact) || empty($type) || empty($status)) {
        header('Location: add_member.php?error=All required fields must be filled');
        exit();
    }

    // Validate admission_no for Student type
    if ($type === 'Student' && empty($admission_no)) {
        header('Location: add_member.php?error=Admission number is required for students');
        exit();
    }

    // Prepare and execute the insert query using prepared statements
    $stmt = $conn->prepare("INSERT INTO member (admission_no, firstname, lastname, gender, address, contact, type, year_level, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        header('Location: add_member.php?error=Failed to prepare statement: ' . $conn->error);
        exit();
    }

    $stmt->bind_param("sssssssss", $admission_no, $firstname, $lastname, $gender, $address, $contact, $type, $year_level, $status);

    if ($stmt->execute()) {
        header('Location: member.php?message=Member added successfully');
    } else {
        header('Location: add_member.php?error=Error adding member: ' . $stmt->error);
    }

    $stmt->close();
} else {
    header('Location: add_member.php?error=Form not submitted');
    exit();
}

mysqli_close($conn);
?>