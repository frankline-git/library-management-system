<DOCUMENT filename="edit_member.php">
<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_dashboard.php'); ?>
<?php $get_id = $_GET['id']; ?>
    <div class="container">
        <div class="margin-top">
            <div class="row">    
                <div class="span12">    
                    <?php 
                    $query = mysqli_query($conn, "SELECT * FROM member WHERE member_id='$get_id'") or die(mysqli_error($conn));
                    $row = mysqli_fetch_array($query);
                    ?>
                    <div class="alert alert-info"><i class="icon-pencil"></i> Edit Member</div>
                    <p><a class="btn btn-info" href="member.php"><i class="icon-arrow-left icon-large"></i> Back</a></p>
                    <div class="addstudent">
                        <div class="details">Please Enter Details Below</div>    
                        <form class="form-horizontal" method="POST" action="update_member.php" enctype="multipart/form-data">
                            <div class="control-group">
                                <label class="control-label" for="admissionNo">Admission No:</label>
                                <div class="controls">
                                    <input type="text" id="admissionNo" name="admission_no" value="<?php echo $row['admission_no']; ?>" placeholder="Admission No" required>
                                    <input type="hidden" id="inputEmail" name="id" value="<?php echo $get_id; ?>" required>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="inputEmail">Firstname:</label>
                                <div class="controls">
                                    <input type="text" id="inputEmail" name="firstname" value="<?php echo $row['firstname']; ?>" placeholder="Firstname" required>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="inputPassword">Lastname:</label>
                                <div class="controls">
                                    <input type="text" id="inputPassword" name="lastname" value="<?php echo $row['lastname']; ?>" placeholder="Lastname" required>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="inputPassword">Gender:</label>
                                <div class="controls">
                                    <select name="gender" required>
                                        <option value="Male" <?php if ($row['gender'] == 'Male') echo 'selected'; ?>>Male</option>
                                        <option value="Female" <?php if ($row['gender'] == 'Female') echo 'selected'; ?>>Female</option>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="inputPassword">Address:</label>
                                <div class="controls">
                                    <input type="text" id="inputPassword" name="address" value="<?php echo $row['address']; ?>" placeholder="Address" required>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="inputPassword">Contact:</label>
                                <div class="controls">
                                    <input type="tel" pattern="[0-9]{0,15}" class="search" name="contact" placeholder="Phone Number" autocomplete="off" maxlength="15" value="<?php echo $row['contact']; ?>">
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="inputPassword">Type:</label>
                                <div class="controls">
                                    <select name="type" required>
                                        <option value="Student" <?php if ($row['type'] == 'Student') echo 'selected'; ?>>Student</option>
                                        <option value="Teacher" <?php if ($row['type'] == 'Teacher') echo 'selected'; ?>>Teacher</option>
                                        <option value="Non Teaching Staff" <?php if ($row['type'] == 'Non Teaching Staff') echo 'selected'; ?>>Non Teaching Staff</option>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="inputPassword">Year Level:</label>
                                <div class="controls">
                                    <select name="year_level" required>
                                        <option value="First Year" <?php if ($row['year_level'] == 'First Year') echo 'selected'; ?>>First Year</option>
                                        <option value="Second Year" <?php if ($row['year_level'] == 'Second Year') echo 'selected'; ?>>Second Year</option>
                                        <option value="Third Year" <?php if ($row['year_level'] == 'Third Year') echo 'selected'; ?>>Third Year</option>
                                        <option value="Fourth Year" <?php if ($row['year_level'] == 'Fourth Year') echo 'selected'; ?>>Fourth Year</option>
                                        <option value="Faculty" <?php if ($row['year_level'] == 'Faculty') echo 'selected'; ?>>Faculty</option>
                                        <option value="Teacher" <?php if ($row['year_level'] == 'Teacher') echo 'selected'; ?>>Teacher</option>
                                        <option value="Researcher" <?php if ($row['year_level'] == 'Researcher') echo 'selected'; ?>>Researcher</option>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group">
                                <label class="control-label" for="inputPassword">Status:</label>
                                <div class="controls">
                                    <select name="status" required>
                                        <option value="Active" <?php if ($row['status'] == 'Active') echo 'selected'; ?>>Active</option>
                                        <option value="Banned" <?php if ($row['status'] == 'Banned') echo 'selected'; ?>>Banned</option>
                                    </select>
                                </div>
                            </div>
                            <div class="control-group">
                                <div class="controls">
                                    <button name="submit" type="submit" class="btn btn-success"><i class="icon-save icon-large"></i> Update</button>
                                </div>
                            </div>
                        </form>                
                    </div>        
                </div>        
            </div>
        </div>
    </div>
<?php include('footer.php') ?>
</DOCUMENT>