<?php
$conn = mysqli_connect('localhost','root','','mlms') or die(mysqli_error());
?>