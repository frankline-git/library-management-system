<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_borrow.php'); ?>
    <div class="container">
        <div class="margin-top">
            <div class="row">    
                <div class="span12">        
                    <?php 
                    if (isset($_GET['success']) && $_GET['success'] == 1) {
                        echo '<div class="alert alert-success">Book returned successfully!</div>';
                    } elseif (isset($_GET['error']) && $_GET['error'] == 1) {
                        echo '<div class="alert alert-error">Error returning book. Please try again.</div>';
                    } elseif (isset($_GET['error']) && $_GET['error'] == 2) {
                        echo '<div class="alert alert-error">Missing parameters. Please try again.</div>';
                    }
                    ?>
                    <div class="alert alert-info"><strong>Borrowed Books</strong></div>
                    <table cellpadding="0" cellspacing="0" border="0" class="table" id="example">
                        <thead>
                            <tr>
                                <th>Book Title</th>                                 
                                <th>Borrower</th>                                 
                                <th>Year Level</th>                                 
                                <th>Date Borrow</th>                                 
                                <th>Due Date</th>                                
                                <th>Date Returned</th>
                                <th>Borrow Status</th>
                                <th>Fine</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php  
                            $user_query = mysqli_query($conn, "SELECT * FROM borrow
                                LEFT JOIN member ON borrow.member_id = member.member_id
                                LEFT JOIN borrowdetails ON borrow.borrow_id = borrowdetails.borrow_id
                                LEFT JOIN book ON borrowdetails.book_id = book.book_id 
                                ORDER BY borrow.borrow_id DESC") or die(mysqli_error($conn));
                            while ($row = mysqli_fetch_array($user_query)) {
                                $id = $row['borrow_id'];
                                $book_id = $row['book_id'];
                                $borrow_details_id = $row['borrow_details_id'];
                                $date_borrow = $row['date_borrow'];
                                $due_date = $row['due_date'];
                                $date_returned = $row['date_returned'];
                                $borrow_status = $row['borrow_status'];
                                $fine = $row['fine'];

                                // Convert dates to DateTime objects for comparison
                                $due_date_obj = DateTime::createFromFormat('d/m/Y', $due_date);
                                if ($due_date_obj === false) {
                                    $due_date_obj = new DateTime(); // Fallback to current date if parsing fails
                                } else {
                                    $due_date_obj->setTime(0, 0, 0); // Set time to midnight for consistent comparison
                                }
                                $current_date = new DateTime('2025-05-19 16:58:00'); // Updated to 04:58 PM EAT

                                // Calculate fine if due date has passed and status is pending
                                if ($borrow_status == 'pending' && $current_date > $due_date_obj) {
                                    $overdue_days = $current_date->diff($due_date_obj)->days;
                                    $fine_rate = 1.00; // 1 KSh per day overdue (adjustable)
                                    $calculated_fine = $overdue_days * $fine_rate;

                                    // Update the fine in the database using prepared statement
                                    $stmt_fine = $conn->prepare("UPDATE borrow SET fine = ? WHERE borrow_id = ?");
                                    $stmt_fine->bind_param("di", $calculated_fine, $id);
                                    $stmt_fine->execute();
                                    $stmt_fine->close();

                                    $fine = $calculated_fine;
                                } else if ($borrow_status == 'returned') {
                                    $fine = 0.00; // Reset fine when returned
                                }
                            ?>
                            <tr class="del<?php echo $id ?>">
                                <td><?php echo $row['book_title']; ?></td>
                                <td><?php echo $row['firstname'] . " " . $row['lastname']; ?></td>
                                <td><?php echo $row['year_level']; ?></td>
                                <td><?php echo $date_borrow; ?></td> 
                                <td><?php echo $due_date; ?></td>
                                <td><?php echo $date_returned ?: 'N/A'; ?></td>
                                <td><?php echo $borrow_status; ?></td>
                                <td><?php echo 'KSh ' . number_format($fine, 2); ?></td>
                                <td><a rel="tooltip" title="Return" id="<?php echo $borrow_details_id; ?>" href="#delete_book<?php echo $borrow_details_id; ?>" data-toggle="modal" class="btn btn-success"><i class="icon-check icon-large"></i>Return</a>
                                <?php include('modal_return.php'); ?>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>    
            </div>
        </div>
    </div>

<script>        
$(".uniform_on").change(function(){
    var max = 3;
    if ($(".uniform_on:checked").length == max) {
        $(".uniform_on").attr('disabled', 'disabled');
        alert('3 Books are allowed per borrow');
        $(".uniform_on:checked").removeAttr('disabled');
    } else {
        $(".uniform_on").removeAttr('disabled');
    }
})
</script>        
<?php include('footer.php') ?>