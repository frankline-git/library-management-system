<DOCUMENT filename="update_member.php">
<?php 
include('dbcon.php');
if (isset($_POST['submit'])) {
    // Sanitize input to prevent SQL injection
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $admission_no = mysqli_real_escape_string($conn, $_POST['admission_no']); // Added admission_no
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $lastname = mysqli_real_escape_string($conn, $_POST['lastname']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $year_level = mysqli_real_escape_string($conn, $_POST['year_level']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    // Update query with admission_no included
    $query = "UPDATE member SET 
              admission_no='$admission_no', 
              firstname='$firstname', 
              lastname='$lastname', 
              gender='$gender', 
              address='$address', 
              contact='$contact', 
              type='$type', 
              year_level='$year_level', 
              status='$status' 
              WHERE member_id='$id'";

    if (mysqli_query($conn, $query)) {
        header('Location: member.php?message=Member updated successfully');
    } else {
        echo "Error updating member: " . mysqli_error($conn);
    }
} else {
    echo "Form not submitted.";
}
?>
</DOCUMENT>