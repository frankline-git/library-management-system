<?php 
include('dbcon.php');
session_start();

if (isset($_GET['id']) && isset($_GET['book_id']) && isset($_GET['borrow_details_id'])) {
    $borrow_id = $_GET['id'];
    $book_id = $_GET['book_id'];
    $borrow_details_id = $_GET['borrow_details_id'];
    $date_returned = '2025-05-14 19:47:00'; // Updated to 07:47 PM EAT

    // Prepare and execute the update query for borrow table
    $stmt_borrow = $conn->prepare("UPDATE borrow 
        SET date_returned = ?, fine = 0.00 
        WHERE borrow_id = ?");
    $stmt_borrow->bind_param("si", $date_returned, $borrow_id);
    $stmt_borrow->execute();

    // Prepare and execute the update query for borrowdetails table
    $stmt_details = $conn->prepare("UPDATE borrowdetails 
        SET borrow_status = 'returned', date_return = ? 
        WHERE borrow_id = ? AND book_id = ? AND borrow_details_id = ?");
    $stmt_details->bind_param("siii", $date_returned, $borrow_id, $book_id, $borrow_details_id);
    $stmt_details->execute();

    if ($stmt_borrow->affected_rows > 0 || $stmt_details->affected_rows > 0) {
        header('location: view_borrow.php?success=1');
    } else {
        header('location: view_borrow.php?error=1');
    }

    $stmt_borrow->close();
    $stmt_details->close();
} else {
    header('location: view_borrow.php?error=2');
}

$conn->close();
exit();
?>